package moduleonemilestone;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("12345", "Brandon", "Hinkle", "7659186557", "2442 Coyner");

        assertEquals("12345", contact.getContactId());
        assertEquals("Brandon", contact.getFirstName());
        assertEquals("Hinkle", contact.getLastName());
        assertEquals("7659186557", contact.getPhone());
        assertEquals("2442 Coyner", contact.getAddress());
    }

    @Test
    public void testContactIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Brandon", "Hinkle", "7659186557", "2442 Coyner");
        });
    }

    @Test
    public void testContactIdCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Brandon", "Hinkle", "7659186557", "2442 Coyner");
        });
    }

    @Test
    public void testFirstNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Hinkle", "7659186557", "2442 Coyner");
        });
    }

    @Test
    public void testFirstNameCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "AnnastasiaX", "Hinkle", "7659186557", "2442 Coyner");
        });
    }

    @Test
    public void testLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Brandon", null, "7659186557", "2442 Coyner");
        });
    }

    @Test
    public void testLastNameCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Brandon", "AnnastasiaX", "7659186557", "2442 Coyner");
        });
    }

    @Test
    public void testPhoneCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Brandon", "Hinkle", null, "2442 Coyner");
        });
    }

    @Test
    public void testPhoneMustBeExactly10Digits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Brandon", "Hinkle", "12345", "2442 Coyner");
        });
    }

    @Test
    public void testAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Brandon", "Hinkle", "7659186557", null);
        });
    }

    @Test
    public void testAddressCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Brandon", "Hinkle", "7659186557",
                    "1234567890123456789012345678901");
        });
    }

    @Test
    public void testUpdateFirstName() {
        Contact contact = new Contact("12345", "Brandon", "Hinkle", "7659186557", "2442 Coyner");
        contact.setFirstName("Bernhard");

        assertEquals("Bernhard", contact.getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        Contact contact = new Contact("12345", "Brandon", "Hinkle", "7659186557", " 2442 Coyner");
        contact.setLastName("Henkel");

        assertEquals("Henkel", contact.getLastName());
    }

    @Test
    public void testUpdatePhone() {
        Contact contact = new Contact("12345", "Brandon", "Hinkle", "7659186557", "2442 Coyner");
        contact.setPhone("7655554321");

        assertEquals("7655554321", contact.getPhone());
    }

    @Test
    public void testUpdateAddress() {
        Contact contact = new Contact("12345", "Brandon", "Hinkle", "3175551234", "123 Main Street");
        contact.setAddress("456 Oak Avenue");

        assertEquals("456 Oak Avenue", contact.getAddress());
    }
}
