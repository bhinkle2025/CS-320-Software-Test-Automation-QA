package moduleonemilestone;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("10001", "Brandon", "Hinkle", "3175551234", "123 Main Street");

        service.addContact(contact);

        assertEquals(contact, service.getContact("10001"));
    }

    @Test
    public void testAddContactWithDuplicateIdFails() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("10001", "Brandon", "Hinkle", "3175551234", "123 Main Street");
        Contact contact2 = new Contact("10001", "John", "Smith", "7655554321", "456 Oak Avenue");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("10001", "Brandon", "Hinkle", "3175551234", "123 Main Street");

        service.addContact(contact);
        service.deleteContact("10001");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("10001");
        });
    }

    @Test
    public void testDeleteNonexistentContactFails() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("99999");
        });
    }

    @Test
    public void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("10001", "Brandon", "Hinkle", "7659186557", "2442 Coyner");
        service.addContact(contact);

        service.updateFirstName("10001", "Bernhard");

        assertEquals("Bernhard", service.getContact("10001").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("10001", "Brandon", "Hinkle", "7659186557", "2442 Coyner");
        service.addContact(contact);

        service.updateLastName("10001", "Henkel");

        assertEquals("Henkel", service.getContact("10001").getLastName());
    }

    @Test
    public void testUpdatePhone() {
        ContactService service = new ContactService();
        Contact contact = new Contact("10001", "Brandon", "Hinkle", "7659186557", "2442 Coyner");
        service.addContact(contact);

        service.updatePhone("10001", "7655554321");

        assertEquals("7655554321", service.getContact("10001").getPhone());
    }

    @Test
    public void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = new Contact("10001", "Brandon", "Hinkle", "7659186557", "2442 Coyner");
        service.addContact(contact);

        service.updateAddress("10001", "456 Elm Street");

        assertEquals("456 Elm Street", service.getContact("10001").getAddress());
    }

    @Test
    public void testUpdateNonexistentContactFails() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("99999", "Brand");
        });
    }
}
